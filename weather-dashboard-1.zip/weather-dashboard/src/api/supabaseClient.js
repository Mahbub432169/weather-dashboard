// before this works you need a project at supabase.com — copy the Project URL
// and anon/public key from Project Settings > API into your .env file as
// VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY,
)

export default supabase
